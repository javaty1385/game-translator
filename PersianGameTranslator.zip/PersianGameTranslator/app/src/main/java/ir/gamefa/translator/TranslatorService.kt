package ir.gamefa.translator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.max

class TranslatorService : Service() {

    companion object {
        const val ACTION_STOP = "ir.gamefa.translator.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "translator"
        private const val NOTIF_ID = 1
        private const val COLOR_ACTIVE = 0xFF1B8F5A.toInt()
        private const val COLOR_BUSY = 0xFFE08A00.toInt()
        private const val COLOR_PAUSED = 0xFF6B7280.toInt()

        @Volatile
        var running = false
    }

    private class Item(val box: Rect, val text: String)

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())

    // ضبط صفحه
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var capW = 0
    private var capH = 0
    private var lastImage: Image? = null
    private var lastFrameAt = 0L

    // نمایش
    private var overlay: FrameLayout? = null
    private var overlayLp: WindowManager.LayoutParams? = null
    private var bubble: TextView? = null

    // وضعیت
    private var paused = false
    private var busy = false
    private var stopped = false
    private var lastKey = ""
    private var lastWarnAt = 0L
    private var aiBlockedUntil = 0L

    private val cacheAi = HashMap<String, String>()
    private val cacheMl = HashMap<String, String>()

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val ml = MlKitTranslator()
    private val claude by lazy { ClaudeTranslator(prefs) }

    private val tickRunnable = Runnable {
        if (!stopped && !paused && !busy && prefs.mode == "auto") startCycle()
    }

    private val frameListener = ImageReader.OnImageAvailableListener { r ->
        val img = try {
            r.acquireLatestImage()
        } catch (_: Exception) {
            null
        }
        if (img != null) {
            lastImage?.close()
            lastImage = img
            lastFrameAt = SystemClock.uptimeMillis()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "مترجم بازی", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (projection != null || stopped) return START_NOT_STICKY

        startForeground(
            NOTIF_ID,
            buildNotification("در حال آماده‌سازی..."),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data == null) {
            shutdown()
            return START_NOT_STICKY
        }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = try {
            mpm.getMediaProjection(code, data)
        } catch (_: Exception) {
            null
        }
        if (proj == null) {
            shutdown()
            return START_NOT_STICKY
        }
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                handler.post { shutdown() }
            }
        }, handler)

        running = true
        addOverlay()
        addBubble()
        try {
            syncDisplay()
        } catch (_: Exception) {
            toast("ضبط صفحه ممکن نشد")
            shutdown()
            return START_NOT_STICKY
        }

        // مدل آفلاین همیشه آماده می‌شود تا هنگام قطع اینترنت جایگزین باشد.
        ml.prepare { ok ->
            if (!ok && prefs.engine == "offline") {
                toast("دانلود مدل آفلاین ناموفق بود. اینترنت (یا VPN) را بررسی کنید.")
            }
        }

        updateNotification("فعال؛ برای توقف، دکمه شناور را ۱ ثانیه نگه دارید")
        if (prefs.mode == "auto") scheduleTick(600)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    // ───────────────────────── ضبط صفحه ─────────────────────────

    /** اندازه نمایشگر را با ضبط هماهنگ می‌کند. اگر تغییری بود true برمی‌گرداند. */
    private fun syncDisplay(): Boolean {
        val proj = projection ?: return false
        val b = wm.maximumWindowMetrics.bounds
        val w = b.width()
        val h = b.height()
        if (vd != null && w == capW && h == capH) return false

        capW = w
        capH = h
        lastImage?.close()
        lastImage = null

        val dpi = resources.displayMetrics.densityDpi
        val newReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        newReader.setOnImageAvailableListener(frameListener, handler)
        val display = vd
        if (display == null) {
            vd = proj.createVirtualDisplay(
                "fa-translate", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, handler
            )
        } else {
            display.resize(w, h, dpi)
            display.surface = newReader.surface
        }
        reader?.close()
        reader = newReader

        overlayLp?.let { lp ->
            lp.width = w
            lp.height = h
            overlay?.let { v -> wm.updateViewLayout(v, lp) }
        }
        return true
    }

    private fun lastImageToBitmap(): Bitmap? {
        val img = lastImage ?: return null
        return try {
            val plane = img.planes[0]
            val rowPixels = plane.rowStride / plane.pixelStride
            val full = Bitmap.createBitmap(rowPixels, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            if (rowPixels != img.width) {
                val cropped = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
                full.recycle()
                cropped
            } else full
        } catch (_: Exception) {
            null
        }
    }

    // ───────────────────────── چرخه ترجمه ─────────────────────────

    private fun scheduleTick(delay: Long) {
        handler.removeCallbacks(tickRunnable)
        handler.postDelayed(tickRunnable, delay)
    }

    private fun startCycle() {
        if (stopped || busy) return
        busy = true
        setBubbleColor(COLOR_BUSY)

        if (syncDisplay()) {
            overlay?.removeAllViews()
            lastKey = ""
        }
        val hadOverlay = (overlay?.childCount ?: 0) > 0
        val start = SystemClock.uptimeMillis()
        // ترجمه‌های قبلی را موقتاً پنهان می‌کنیم تا متن اصلی بازی خوانده شود.
        if (hadOverlay) overlay?.visibility = View.INVISIBLE
        waitForFrame(hadOverlay, start)
    }

    private fun waitForFrame(needFresh: Boolean, start: Long) {
        if (stopped) return
        val waited = SystemClock.uptimeMillis() - start
        val ready = lastImage != null &&
            (!needFresh || lastFrameAt >= start + 70 || waited > 600)
        when {
            ready -> captureAndRecognize()
            waited > 1500 -> {
                overlay?.visibility = View.VISIBLE
                finishCycle(true)
            }
            else -> handler.postDelayed({ waitForFrame(needFresh, start) }, 40)
        }
    }

    private fun captureAndRecognize() {
        val bmp = lastImageToBitmap()
        overlay?.visibility = View.VISIBLE
        if (bmp == null) {
            finishCycle(true)
            return
        }
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { t ->
                bmp.recycle()
                onText(t)
            }
            .addOnFailureListener {
                bmp.recycle()
                finishCycle(true)
            }
    }

    private fun onText(t: Text) {
        if (stopped) return
        val items = ArrayList<Item>()
        for (block in t.textBlocks) {
            val box = block.boundingBox ?: continue
            val s = block.text.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
            if (isTranslatable(s)) items.add(Item(box, s))
        }

        if (items.isEmpty()) {
            clearOverlay()
            lastKey = ""
            finishCycle(true)
            return
        }

        val key = items.joinToString("|") { it.text }
        if (key == lastKey && (overlay?.childCount ?: 0) > 0) {
            finishCycle(true) // چیزی تغییر نکرده؛ ترجمه‌ها همان‌طور می‌مانند
            return
        }

        val useAi = prefs.engine == "ai" && prefs.apiKey.isNotBlank() &&
            SystemClock.uptimeMillis() >= aiBlockedUntil
        val missing = items.map { it.text }.distinct().filter { s ->
            if (useAi) !cacheAi.containsKey(s) else !(cacheAi.containsKey(s) || cacheMl.containsKey(s))
        }

        val finish = {
            if (!stopped) {
                trimCaches()
                render(items)
                lastKey = if (items.all { lookup(it.text) != null }) key else ""
                finishCycle(false)
            }
        }
        if (missing.isEmpty()) finish() else translateMissing(missing, useAi, finish)
    }

    private fun translateMissing(missing: List<String>, useAi: Boolean, done: () -> Unit) {
        if (!useAi) {
            viaOffline(missing, done)
            return
        }
        claude.translate(missing) { res ->
            if (stopped) return@translate
            val failed = ArrayList<String>()
            missing.forEachIndexed { i, s ->
                val r = res.getOrNull(i)
                if (r != null) cacheAi[s] = r else failed.add(s)
            }
            if (failed.isEmpty()) {
                done()
            } else {
                aiBlockedUntil = SystemClock.uptimeMillis() + 20_000
                warn((claude.lastError ?: "ارتباط برقرار نشد") + " — ترجمه آفلاین استفاده شد")
                viaOffline(failed.filter { !cacheMl.containsKey(it) }, done)
            }
        }
    }

    private fun viaOffline(list: List<String>, done: () -> Unit) {
        if (list.isEmpty()) {
            done()
            return
        }
        ml.translate(list) { res ->
            if (stopped) return@translate
            list.forEachIndexed { i, s -> res.getOrNull(i)?.let { cacheMl[s] = it } }
            done()
        }
    }

    private fun lookup(s: String): String? = cacheAi[s] ?: cacheMl[s]

    private fun trimCaches() {
        if (cacheAi.size > 1500) cacheAi.clear()
        if (cacheMl.size > 1500) cacheMl.clear()
    }

    private fun finishCycle(unchanged: Boolean) {
        busy = false
        setBubbleColor(if (paused) COLOR_PAUSED else COLOR_ACTIVE)
        if (!stopped && !paused && prefs.mode == "auto") {
            scheduleTick(if (unchanged) 2200 else 1200)
        }
    }

    /** فقط متن‌های انگلیسیِ واقعی؛ نه عدد و نماد. */
    private fun isTranslatable(s: String): Boolean {
        if (s.length < 3) return false
        val letters = s.count { it in 'A'..'Z' || it in 'a'..'z' }
        return letters >= 3 && letters * 10 >= s.length * 4
    }

    // ───────────────────────── نمایش ترجمه ─────────────────────────

    private fun render(items: List<Item>) {
        val root = overlay ?: return
        root.removeAllViews()
        if (paused) return
        val alpha = prefs.opacity.coerceIn(30, 100) * 255 / 100
        val bg = Color.argb(alpha, 16, 18, 28)
        val pad = dp(3)

        for (item in items) {
            val fa = lookup(item.text) ?: continue
            if (fa.trim().equals(item.text, ignoreCase = true)) continue

            val box = Rect(item.box)
            box.inset(-pad, -pad)

            val tv = TextView(this).apply {
                text = fa
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                includeFontPadding = false
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                textDirection = View.TEXT_DIRECTION_RTL
                setPadding(dp(3), dp(1), dp(3), dp(1))
                background = GradientDrawable().apply {
                    setColor(bg)
                    cornerRadius = dp(6).toFloat()
                }
                setAutoSizeTextTypeUniformWithConfiguration(
                    8, 24, 1, TypedValue.COMPLEX_UNIT_SP
                )
            }
            val lp = FrameLayout.LayoutParams(
                max(box.width(), dp(24)),
                max(box.height(), dp(18))
            )
            lp.leftMargin = box.left
            lp.topMargin = box.top
            root.addView(tv, lp)
        }
    }

    private fun clearOverlay() {
        overlay?.removeAllViews()
    }

    private fun addOverlay() {
        val b = wm.maximumWindowMetrics.bounds
        val root = FrameLayout(this)
        val lp = WindowManager.LayoutParams(
            b.width(), b.height(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        wm.addView(root, lp)
        overlay = root
        overlayLp = lp
    }

    // ───────────────────────── دکمه شناور ─────────────────────────

    private fun addBubble() {
        val tv = TextView(this).apply {
            text = "فا"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val lp = WindowManager.LayoutParams(
            dp(48), dp(48),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(160)
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        var longFired = false
        val longPress = Runnable {
            longFired = true
            shutdown()
        }

        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    longFired = false
                    handler.postDelayed(longPress, 1000)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) {
                        moved = true
                        handler.removeCallbacks(longPress)
                    }
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    if (!moved && !longFired) onBubbleTap()
                }
                MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longPress)
            }
            true
        }

        wm.addView(tv, lp)
        bubble = tv
        setBubbleColor(COLOR_ACTIVE)
    }

    private fun onBubbleTap() {
        if (stopped) return
        if (prefs.mode == "auto") {
            paused = !paused
            if (paused) {
                handler.removeCallbacks(tickRunnable)
                clearOverlay()
                lastKey = ""
                setBubbleColor(COLOR_PAUSED)
            } else {
                setBubbleColor(COLOR_ACTIVE)
                scheduleTick(0)
            }
        } else {
            // حالت لمسی: بار اول ترجمه می‌کند، بار دوم ترجمه را پاک می‌کند.
            if ((overlay?.childCount ?: 0) > 0) {
                clearOverlay()
                lastKey = ""
            } else if (!busy) {
                startCycle()
            }
        }
    }

    private fun setBubbleColor(color: Int) {
        bubble?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            setStroke(dp(2), Color.WHITE)
        }
    }

    // ───────────────────────── کمکی‌ها ─────────────────────────

    private fun buildNotification(text: String): Notification {
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, TranslatorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_stat)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("مترجم بازی")
            .setContentText(text)
            .setContentIntent(openPi)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icon, "توقف", stopPi).build())
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(text))
    }

    private fun warn(msg: String) {
        val now = SystemClock.uptimeMillis()
        if (now - lastWarnAt > 30_000) {
            lastWarnAt = now
            toast(msg)
        }
    }

    private fun toast(msg: String) {
        handler.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun shutdown() {
        if (stopped) return
        stopped = true
        running = false
        handler.removeCallbacksAndMessages(null)
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        overlay = null
        bubble = null
        lastImage?.close()
        lastImage = null
        vd?.release()
        vd = null
        reader?.close()
        reader = null
        val p = projection
        projection = null
        try { p?.stop() } catch (_: Exception) {}
        try { recognizer.close() } catch (_: Exception) {}
        ml.close()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
}
