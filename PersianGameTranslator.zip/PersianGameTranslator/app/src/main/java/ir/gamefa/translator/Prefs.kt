package ir.gamefa.translator

import android.content.Context

/** تنظیمات برنامه (فقط روی خود گوشی ذخیره می‌شود). */
class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** "ai" = ترجمه هوشمند، "offline" = ترجمه آفلاین */
    var engine: String
        get() = p.getString("engine", "ai") ?: "ai"
        set(v) = p.edit().putString("engine", v).apply()

    /** "auto" = خودکار، "tap" = با لمس دکمه شناور */
    var mode: String
        get() = p.getString("mode", "auto") ?: "auto"
        set(v) = p.edit().putString("mode", v).apply()

    var apiKey: String
        get() = p.getString("apiKey", "") ?: ""
        set(v) = p.edit().putString("apiKey", v).apply()

    var baseUrl: String
        get() = p.getString("baseUrl", "https://api.anthropic.com") ?: "https://api.anthropic.com"
        set(v) = p.edit().putString("baseUrl", v).apply()

    var gameName: String
        get() = p.getString("gameName", "") ?: ""
        set(v) = p.edit().putString("gameName", v).apply()

    var glossary: String
        get() = p.getString("glossary", "") ?: ""
        set(v) = p.edit().putString("glossary", v).apply()

    /** شفافیت پس‌زمینه ترجمه، از ۳۰ تا ۱۰۰ */
    var opacity: Int
        get() = p.getInt("opacity", 90)
        set(v) = p.edit().putInt("opacity", v).apply()
}
