package ir.gamefa.translator

import android.os.Handler
import android.os.Looper
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * ترجمه هوشمند با Claude.
 * همه متن‌های یک صفحه یک‌جا فرستاده می‌شود تا مترجم از موقعیت بازی آگاه باشد
 * و ترجمه روان و طبیعی (نه کلمه‌به‌کلمه) تحویل بدهد.
 */
class ClaudeTranslator(private val prefs: Prefs) {

    @Volatile
    var lastError: String? = null

    private val main = Handler(Looper.getMainLooper())

    companion object {
        private val executor = Executors.newSingleThreadExecutor()
        private const val MODEL = "claude-haiku-5-5"

        private const val SYSTEM_PROMPT = """You are an expert game localizer. You translate on-screen text from video games (menus, buttons, quest text, item names, dialogue, tutorials, chat) from English into natural, fluent Persian (Farsi).

Rules:
- Never translate word-for-word. Write what a native Persian speaker would naturally say. The result must read like it was originally written in Persian, not like machine translation.
- Dialogue: keep the speaker's tone and personality (casual, formal, angry, funny). Use natural spoken Persian when the English is casual.
- Menus, buttons and HUD labels: keep them very short and clear, using the terms Persian gamers actually use.
- Keep numbers, stats, player names, character names and brand names as they are (character and place names may be written in Persian script when that is natural).
- The text comes from OCR and may contain small recognition errors or broken line breaks. Infer the intended meaning from context.
- If an item is not real text (random symbols, a bare number, an unreadable fragment), return it unchanged.
- Follow the glossary exactly when one is given.
- Output ONLY a JSON array of strings, with exactly as many items as the input, in the same order. No explanations, no markdown."""
    }

    fun translate(texts: List<String>, onDone: (List<String?>) -> Unit) {
        if (texts.isEmpty()) {
            onDone(emptyList())
            return
        }
        executor.execute {
            val result: List<String?> = try {
                lastError = null
                call(texts)
            } catch (e: Exception) {
                lastError = e.message ?: "خطای ناشناخته"
                texts.map { null }
            }
            main.post { onDone(result) }
        }
    }

    private fun call(texts: List<String>): List<String> {
        val key = prefs.apiKey.trim()
        if (key.isEmpty()) throw IOException("کلید API وارد نشده است")

        val input = JSONArray()
        texts.forEachIndexed { i, t -> input.put(JSONObject().put("id", i).put("text", t)) }

        val user = StringBuilder()
        if (prefs.gameName.isNotBlank()) user.append("Game: ").append(prefs.gameName.trim()).append("\n")
        if (prefs.glossary.isNotBlank()) {
            user.append("Glossary (English = Persian), follow exactly:\n")
                .append(prefs.glossary.trim()).append("\n")
        }
        user.append("Translate these ").append(texts.size).append(" items. ")
            .append("Return only a JSON array of ").append(texts.size).append(" strings.\n\n")
            .append(input.toString())

        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 2048)
            .put("system", SYSTEM_PROMPT)
            .put(
                "messages",
                JSONArray().put(JSONObject().put("role", "user").put("content", user.toString()))
            )

        val base = prefs.baseUrl.trim().trimEnd('/').ifEmpty { "https://api.anthropic.com" }
        val conn = URL("$base/v1/messages").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 8000
            conn.readTimeout = 25000
            conn.doOutput = true
            conn.setRequestProperty("x-api-key", key)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.setRequestProperty("content-type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                throw IOException(
                    when (code) {
                        401, 403 -> "کلید API نامعتبر است"
                        429 -> "تعداد درخواست‌ها زیاد است، کمی صبر کنید"
                        else -> "خطای سرور ($code)"
                    }
                )
            }

            val text = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
            val s = text.indexOf('[')
            val e = text.lastIndexOf(']')
            if (s < 0 || e <= s) throw IOException("پاسخ نامعتبر از مترجم")
            val out = JSONArray(text.substring(s, e + 1))
            if (out.length() != texts.size) throw IOException("پاسخ ناقص از مترجم")
            return List(out.length()) { out.getString(it) }
        } finally {
            conn.disconnect()
        }
    }
}

/** ترجمه آفلاین (روی خود گوشی). بعد از دانلود یک‌باره مدل بدون اینترنت کار می‌کند. */
class MlKitTranslator {
    private val tr = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.PERSIAN)
            .build()
    )

    @Volatile
    var ready = false

    fun prepare(onResult: (Boolean) -> Unit) {
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                ready = true
                onResult(true)
            }
            .addOnFailureListener { onResult(false) }
    }

    fun translate(texts: List<String>, onDone: (List<String?>) -> Unit) {
        if (!ready || texts.isEmpty()) {
            onDone(texts.map { null })
            return
        }
        val out = arrayOfNulls<String>(texts.size)
        val left = AtomicInteger(texts.size)
        texts.forEachIndexed { i, t ->
            tr.translate(t)
                .addOnSuccessListener { out[i] = it }
                .addOnCompleteListener { if (left.decrementAndGet() == 0) onDone(out.toList()) }
        }
    }

    fun close() {
        try {
            tr.close()
        } catch (_: Exception) {
        }
    }
}
