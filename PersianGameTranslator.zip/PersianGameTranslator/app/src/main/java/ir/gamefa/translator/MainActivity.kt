package ir.gamefa.translator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private companion object {
        const val REQ_CAPTURE = 1
        const val REQ_OVERLAY = 2
        const val REQ_NOTIF = 3
        const val GREEN = 0xFF1B8F5A.toInt()
    }

    private lateinit var prefs: Prefs
    private var askedNotif = false

    private lateinit var rbAi: RadioButton
    private lateinit var rbOffline: RadioButton
    private lateinit var rbAuto: RadioButton
    private lateinit var rbTap: RadioButton
    private lateinit var etKey: EditText
    private lateinit var etBase: EditText
    private lateinit var etGame: EditText
    private lateinit var etGlossary: EditText
    private lateinit var seek: SeekBar
    private lateinit var tvTest: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val scroll = ScrollView(this).apply { setBackgroundColor(0xFFF2F5F3.toInt()) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(32))
        }
        scroll.addView(col)

        col.addView(text("مترجم بازی", 28f, bold = true, color = GREEN))
        col.addView(text("ترجمه زنده و روان متن بازی به فارسی", 14f, color = 0xFF55606A.toInt()))
        col.addView(space(16))

        // موتور ترجمه
        rbAi = radio("هوش مصنوعی (ترجمه روان و طبیعی، نیاز به اینترنت و کلید API)")
        rbOffline = radio("آفلاین (سریع و بدون اینترنت، ترجمه ماشینی ساده‌تر)")
        val engineGroup = RadioGroup(this).apply {
            addView(rbAi)
            addView(rbOffline)
        }
        etKey = field("کلید API (شروع با sk-ant-)", password = true)
        etBase = field("آدرس سرور (اختیاری، پیش‌فرض را تغییر ندهید)")
        etGame = field("نام بازی (مثلاً Genshin Impact) تا ترجمه دقیق‌تر شود")
        etGlossary = field("واژه‌نامه شما: هر خط  English = فارسی", lines = 4)
        val btnTest = button("تست ترجمه", outline = true) { runTest() }
        tvTest = text("", 14f, color = 0xFF1F2937.toInt())

        col.addView(card("موتور ترجمه", engineGroup, etKey, etGame, etGlossary, btnTest, tvTest, etBase))

        // حالت کار
        rbAuto = radio("خودکار: مدام صفحه را ترجمه می‌کند")
        rbTap = radio("لمسی: فقط وقتی دکمه شناور را بزنید")
        col.addView(card("حالت کار", RadioGroup(this).apply {
            addView(rbAuto)
            addView(rbTap)
        }))

        // ظاهر
        seek = SeekBar(this).apply { max = 70 }
        col.addView(card("ظاهر ترجمه", text("غلظت پس‌زمینه متن فارسی", 13f), seek))

        col.addView(button("شروع ترجمه", outline = false) { startFlow() })
        col.addView(space(8))
        col.addView(button("توقف", outline = true) {
            startService(Intent(this, TranslatorService::class.java).setAction(TranslatorService.ACTION_STOP))
        })

        col.addView(space(16))
        col.addView(
            text(
                "راهنما: بعد از «شروع»، در پنجره‌ای که اندروید نشان می‌دهد گزینه «کل صفحه» (Entire screen) را انتخاب کنید. " +
                    "سپس بازی را باز کنید. دکمه سبز «فا» روی صفحه می‌ماند: لمس = روشن/خاموش، کشیدن = جابه‌جایی، ۱ ثانیه نگه داشتن = توقف.",
                13f, color = 0xFF55606A.toInt()
            )
        )

        setContentView(scroll)
        load()
    }

    override fun onPause() {
        save()
        super.onPause()
    }

    // ───────────────────────── تنظیمات ─────────────────────────

    private fun load() {
        (if (prefs.engine == "offline") rbOffline else rbAi).isChecked = true
        (if (prefs.mode == "tap") rbTap else rbAuto).isChecked = true
        etKey.setText(prefs.apiKey)
        etBase.setText(prefs.baseUrl)
        etGame.setText(prefs.gameName)
        etGlossary.setText(prefs.glossary)
        seek.progress = (prefs.opacity - 30).coerceIn(0, 70)
    }

    private fun save() {
        prefs.engine = if (rbOffline.isChecked) "offline" else "ai"
        prefs.mode = if (rbTap.isChecked) "tap" else "auto"
        prefs.apiKey = etKey.text.toString().trim()
        prefs.baseUrl = etBase.text.toString().trim().ifEmpty { "https://api.anthropic.com" }
        prefs.gameName = etGame.text.toString().trim()
        prefs.glossary = etGlossary.text.toString().trim()
        prefs.opacity = seek.progress + 30
    }

    private fun runTest() {
        save()
        tvTest.text = "در حال ترجمه..."
        val c = ClaudeTranslator(prefs)
        c.translate(
            listOf(
                "Press any key to continue.",
                "Quest completed! You earned 200 XP and a rare sword."
            )
        ) { r ->
            tvTest.text = if (r.isNotEmpty() && r[0] != null) {
                r.joinToString("\n") { it ?: "—" }
            } else {
                "خطا: " + (c.lastError ?: "نامشخص")
            }
        }
    }

    // ───────────────────────── شروع ─────────────────────────

    private fun startFlow() {
        save()
        if (prefs.engine == "ai" && prefs.apiKey.isBlank()) {
            toast("برای ترجمه هوشمند کلید API لازم است؛ یا حالت آفلاین را انتخاب کنید.")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("اجازه «نمایش روی سایر برنامه‌ها» را روشن کنید و برگردید.")
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                REQ_OVERLAY
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_OVERLAY -> if (Settings.canDrawOverlays(this)) startFlow()
            REQ_CAPTURE -> if (resultCode == RESULT_OK && data != null) {
                startForegroundService(
                    Intent(this, TranslatorService::class.java)
                        .putExtra(TranslatorService.EXTRA_CODE, resultCode)
                        .putExtra(TranslatorService.EXTRA_DATA, data)
                )
                moveTaskToBack(true)
            } else {
                toast("اجازه ضبط صفحه داده نشد.")
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) startFlow()
    }

    // ───────────────────────── ساخت رابط ─────────────────────────

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun space(h: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h))
    }

    private fun text(s: String, size: Float, bold: Boolean = false, color: Int = 0xFF111827.toInt()) =
        TextView(this).apply {
            text = s
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(2), 0, dp(2))
        }

    private fun radio(s: String) = RadioButton(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
    }

    private fun field(hint: String, password: Boolean = false, lines: Int = 1) = EditText(this).apply {
        this.hint = hint
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        textDirection = View.TEXT_DIRECTION_LOCALE
        if (password) {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else if (lines > 1) {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = lines
            gravity = Gravity.TOP or Gravity.START
        } else {
            inputType = InputType.TYPE_CLASS_TEXT
        }
    }

    private fun button(label: String, outline: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        setTextColor(if (outline) GREEN else Color.WHITE)
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            if (outline) {
                setColor(Color.WHITE)
                setStroke(dp(2), GREEN)
            } else {
                setColor(GREEN)
            }
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun card(title: String, vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(14).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) }
        addView(text(title, 16f, bold = true))
        views.forEach { addView(it) }
    }
}
