plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.gamefa.translator"
    compileSdk = 34

    defaultConfig {
        applicationId = "ir.gamefa.translator"
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // خواندن متن از تصویر (روی خود گوشی، بدون اینترنت)
    implementation("com.google.mlkit:text-recognition:16.0.1")
    // ترجمه انگلیسی به فارسی (روی خود گوشی، بعد از دانلود یک‌باره مدل)
    implementation("com.google.mlkit:translate:17.0.3")
}
